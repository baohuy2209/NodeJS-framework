declare module "tailwindcss/lib/util/flattenColorPalette" {
  const flattenColorPalette: (colors: object) => object;
  export default flattenColorPalette;
}
