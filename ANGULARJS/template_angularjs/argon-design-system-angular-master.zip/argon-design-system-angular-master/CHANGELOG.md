## [1.3.0] - 2022-04-08
### Updates
- update to Angular 13
- update all dependencies to match Angular 13 version
- ng-bootstrap tab implementation changed
- cosmetic changes due to change of components

## [1.2.0] - 2021-01-04
### Updates
- update to Angular 11
- update all dependencies to match Angular 11 version

## [1.1.0] - 2020-03-09
### Updates
- update to Angular 9
- update all dependencies to match Angular 9 version

## [1.0.0] - 2019-03-29
### Initial Release
