## [1.0.0] 2021-02-02
### Original Release
- Added Reactstrap as base framework
- Added design from Argon Dashboard by Creative Tim
- Added Node Js API
