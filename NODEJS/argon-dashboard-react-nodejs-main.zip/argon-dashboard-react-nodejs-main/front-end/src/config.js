const config = {
    WS_BASE_URL: 'http://localhost:5100/api/',
    DOMAIN_NAME: 'http://localhost:3000',
    DEMO: true
}

export default config;
