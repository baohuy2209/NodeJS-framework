async function loadPage(req, res) {
  res.render('pages/reset-password');
}

module.exports = loadPage;
