# Changelog

All notable changes to `Vue Black Dashboard Laravel`  will be documented in this file.

## Version 1.0.0

### Added
- Vue Black Dashboard Free
- Login
- Register
- Profile edit

## Version 1.0.1
Update to Laravel 9.x

## Version 1.1.0
Update to Laravel 11.x
