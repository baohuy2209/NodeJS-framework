<template>
  <div>Welcome to <b>Black Dashboard</b> - a beautiful freebie for every web developer.</div>
</template>

<script>
  export default {
    name: 'notification-template'
  }
</script>
